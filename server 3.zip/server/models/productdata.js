const mongoose=require('mongoose');
const Schema=mongoose.Schema;
const db='mongodb://localhost:27017/productsdb'
mongoose.connect(
    db, function (err) {
        if (err) { console.error ('error is shown as'+err)}
        else {console.log('connected to mongodb')}
    }
);


var NewProductSchema=new Schema ({

    productId: Number,
    productName:String,
    productCode:String,
    releaseDate:String,
    description : String,
    price: Number,
    starRating: Number,
    imageUrl:String
});



var Productdata= mongoose.model( 'product', NewProductSchema, 'product');
module.exports= Productdata;