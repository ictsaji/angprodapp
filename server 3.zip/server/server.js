const express=require ('express');
const bodyparser=require('body-parser');
//const ProductData= require ('./src/model/Productdata');

const api=require('./routes/api');
//const port=3000;
const cors=require ('cors')



const app=new express ();


app.use(express.urlencoded( {extended:true}));
app.use (bodyparser.json());
app.use ('/api', api);
app.use (cors ());


app.get ( "/", function (req,res)
        { 
            res.send ("hello from server");

        });


app.listen (3232, function ()
{
    console.log ("server is running on port number:" );
}
) ;       