const express = require('express');

const router = express.Router();
const mongoose=require ('mongoose');
const ProductData=require ('../models/productdata');
const db='mongodb://localhost:27017/productsdb'
mongoose.connect(
    db, function (err) {
        if (err) { console.error ('error is shown as'+err)}
        else {console.log('connected to mongodb')}
    }
);



router.get ("/", function (req, res)
{res.send ("from api")});

router.get ( '/products', function (req, res)
            { 
                res.header ("Access-Control-Allow-Origin", "*")
                res.header (  "Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
                ProductData.find ()
                .then (function (products){
                    res.send (products);
                })
            
            
            });

 router.post ( '/insert', function (res,req) 
                        {   res.header ("Access-Control-Allow-Origin", "*")
                            res.header (  "Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
                            console.log(req.body);
                             var product= {
                                productId: req.body.product.productId,
                                productName: req.body.product.productName,
                                productCode: req.body.product.productCode,
                                releaseDate: req.body.product.releaseDate,
                                description: req.body.product.description,
                                price: req.body.product.price,
                                starRating: req.body.product.starRating,
                                imageUrl: req.body.product.imageUrl
                                }
                            var product= new ProductData(product);
                            product.save();
                            console.log(product);
                        });           


 



module.exports=router;