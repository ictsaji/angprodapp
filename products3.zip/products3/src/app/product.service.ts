import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class ProductService {

    constructor( private http:HttpClient) { }
    code:string;
    getProducts() 
           { return this.http.get ("http://localhost:3232/api/products");}

    newProduct(item) 
      {
        return this.http.post("http://localhost:3232/api/insert", {"product":item})
        .subscribe(function (data) {console.log (data)});
          
        }


    deleteProduct(code) {

      //return this.http.delete(`${"this.baseUrl"}/${code}`)
      return this.http.delete("http://localhost:3232/api/deleteProduct", code)
   

    }


  
  
  
}
