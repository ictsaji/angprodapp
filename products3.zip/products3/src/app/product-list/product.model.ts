export class ProductModel{
      constructor( 

        public productId: Number,
        public productName: string,
        public productCode: string,
        
        public releaseDate: string,
        public description: string,
        public price: Number,
        public starRating: Number,
        public imageUrl: String

      ){}


}