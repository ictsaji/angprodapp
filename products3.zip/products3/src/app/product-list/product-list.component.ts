import { Component, OnInit } from '@angular/core';
import {ProductModel} from './product.model';
import {ProductService} from '../product.service';
import {Router} from '@angular/router'



@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})


export class ProductListComponent implements OnInit {


  title:string="product List";
  products: ProductModel[];
  imageWidth: number=50;
  imageMargin: number=2;

  showImage: boolean=false;

  
  constructor( private productService:ProductService,  private router: Router) { }
  
  toggleImage() {
    this.showImage=!this.showImage;
  }

  ngOnInit() {

          this.productService.getProducts ().subscribe (

          (data) => {
            this.products=JSON.parse (JSON.stringify (data));
          }
          )
  }

  deleteProduct (code: string) {
      
      this.productService.deleteProduct (code)
  //    .subscribe( 
  //      function (data) {
  //        console.log(data);

  //        this.productService.getProducts ().subscribe (

  //         (data) => {
  //           this.products=JSON.parse (JSON.stringify (data));
  //         }
  //         )

  //      } 
  //     )

          
                   this.router.navigate (['/']);
   }

}
